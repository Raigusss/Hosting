<?php
include ("switch.php");
?>
<tr>
        <td width="25%">
            <font size="2" color="black" face="tahoma">
                <b>&nbsp;
                    <i>mikocahyo275@gmail.com</i>
                </b>
            </font>
        </td>

        <td width="10%" bgcolor="mediumblue"align="center">
            <a href="index.php" style="text-decoration:none;">
            <font color="skyblue" face="calibri"><b>HOME</b></font></a>
        </td>

        <td width="10%" bgcolor="skyublue"align="center">
            <a href="input_awal.php" style="text-decoration:none;">
            <font color="skyblue" face="calibri"><b>INPUT</b></font></a>
        </td>

        <td width="10%" bgcolor="skyublue"align="center">
            <a href="bintang_output.php" style="text-decoration:none;">
            <font color="skyblue" face="calibri"><b>BINTANG</b></font></a>
        </td>
        

        <td width="10%" align="center">
            <a href="" style="text-decoration:none;"/font></a>
        </td>

        <td width="10%" align="center">
            <a href="" style="text-decoration:none;"/font></a>
        </td>

        <td align="right">
            <font size="3" color="green">
                <b><i>
                <?php //echo "$hari, $tgl $bln $thn"; ?>
                </i></b>&nbsp;
            </font>
        </td>
</tr>
</tr>
<td colspan="7"><hr></td>
</tr?