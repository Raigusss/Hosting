<tr>
    <td width="100%" colspan="7">
        <table border="0" width="100%">
        <tr>
            <td width="11%">
                <img src="unidaclear.png" width="130">
            </td>
            <td align="center">
                <font size="7" color="blue" face="broadway">Struktur Data</font><br>
                <font size="5" color="darkmagenta" face="impact">
                    Universitas Djuanda - 2024
                </font>
            </td>
        </tr>
        </table>

        </td>
</tr>

