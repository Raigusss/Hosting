<tr height="59" valign="bottom">
    <td colspan="left">
        <font size="2" color="cyan" face="calibri"><b>.::Created by ... 2024 :..</b></font>
    </td>
</tr>
        