<body style="background:url('green1.jpg'); background-repeat;no-repeat; background-size: 100% 100%">
<table width="100%"border="0">

<?php
    include "atas.php";
    include "menu.php";
?>

<tr>
    <td height="360" colspan="7" align="center">
        &nbsp;
     </td>
<tr>

<?php
    include "bawah.php";
?>

</table>
</body>